import React from "react";

let Alert = () => {
    return (
        <React.Fragment>
            <h2>Alert</h2>
        </React.Fragment>
    )
};
export default Alert;