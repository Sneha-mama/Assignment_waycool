import React from "react";

let Spinner = () => {
    return (
        <React.Fragment>
            <h2>Spinner</h2>
        </React.Fragment>
    )
};
export default Spinner;