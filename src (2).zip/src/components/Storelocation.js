import React from 'react';

const Storelocation = () => {
    return (
        <React.Fragment>

        </React.Fragment>
    )
};
export default Storelocation;