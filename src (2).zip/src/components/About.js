import React from 'react';

const About = () => {
    return (
        <React.Fragment>
             <div>
                 About
             </div>
        </React.Fragment>
    )
};
export default About;