import React from 'react';

const Logo = () => {
    return (
        <React.Fragment>
           <div>
               Home
           </div>
        </React.Fragment>
    )
};
export default Logo;