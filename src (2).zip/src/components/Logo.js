import React from 'react';

const Logo = () => {
    return (
        <React.Fragment>
             <div>
                 Logo
             </div>
        </React.Fragment>
    )
};
export default Logo;