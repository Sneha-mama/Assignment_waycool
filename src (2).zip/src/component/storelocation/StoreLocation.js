import React from 'react';

const StoreLocation = () => {
    return (
        <React.Fragment>
            <div>
                StoreLocation
            </div>
        </React.Fragment>
    )
};
export default StoreLocation;