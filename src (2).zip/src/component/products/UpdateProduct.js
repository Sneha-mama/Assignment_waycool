import React from "react";

class UpdateProduct extends React.Component{
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <React.Fragment>
                <p className="h3">UpdateProduct</p>
            </React.Fragment>
        );
    }
}
export default UpdateProduct;