import React from "react";

class CreateProduct extends React.Component{
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <React.Fragment>
                <div className="container mt-3">
                    <div className="row">
                        <div className="col">
                            <p className="h3">Creat a Product</p>
                            <p className="lead">Lorem ipsum dolor sit amet.</p>
                        </div>
                    </div>
                    </div>                
            </React.Fragment>
        );
    }
}
export default CreateProduct;