import React from 'react';

const Contact = () => {
    return (
        <React.Fragment>
            <div>
                Contact
            </div>
        </React.Fragment>
    )
};
export default Contact;