import React from 'react';

const AboutUs = () => {
    return (
        <React.Fragment>
            <div>
                AboutUs
            </div>
        </React.Fragment>
    )
};
export default AboutUs;