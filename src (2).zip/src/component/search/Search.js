import React from 'react';

const Search = () => {
    return (
        <React.Fragment>
            <div>
                Search
            </div>
        </React.Fragment>
    )
};
export default Search;