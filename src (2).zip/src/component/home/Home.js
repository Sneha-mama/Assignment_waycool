import React from 'react';

const Home = () => {
    return (
        <React.Fragment>
            <div>
                <div className="landing-page">
                    <div className="wrapper">
                        <div>
                            <h5 className="display-4">
                                Auto scroll Banners
                            </h5>
                        </div>
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
};
export default Home;