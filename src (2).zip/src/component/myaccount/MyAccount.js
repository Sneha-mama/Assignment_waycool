import React from 'react';

const MyAccount = () => {
    return (
        <React.Fragment>
            <div>
                MyAccount
            </div>
        </React.Fragment>
    )
};
export default MyAccount;