import React from 'react';

const Cart = () => {
    return (
        <React.Fragment>
            <div>
                Cart
            </div>
        </React.Fragment>
    )
};
export default Cart;