import React from 'react';

const Location = () => {
    return (
        <React.Fragment>
            <div>
                Location
            </div>
        </React.Fragment>
    )
};
export default Location;