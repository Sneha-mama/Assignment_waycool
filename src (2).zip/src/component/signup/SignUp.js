import React from 'react';

const SignUp = () => {
    return (
        <React.Fragment>
            <div>
                SignUp
            </div>
        </React.Fragment>
    )
};
export default SignUp;