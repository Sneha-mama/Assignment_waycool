import React from 'react';

const Login = () => {
    return (
        <React.Fragment>
            <div>
                Login
            </div>
        </React.Fragment>
    )
};
export default Login;